﻿Mathieu THEBAUD
Nathan VILLIOT

Projet d'AP5 - IUT Vannes


#JUnit
setenv CLASSPATH ${CLASSPATH}:../lib/junit-4.11.jar:../lib/hamcrest-core-1.3.jar

#Création
cd projetPDA
ant -f ant/build.xml init

#Liens
ln -s ../ant/build.xml build.xml
ln -s ../data data
